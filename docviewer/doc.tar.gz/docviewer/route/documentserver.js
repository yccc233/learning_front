
var router = require('express').Router();
var request = require('request');
var midServer = require('../rest/midserver');

router.get("/downloadFile", function (req, res) {
	if (req.query.url) {
		// 自配置url，无此参调用默认下载， url格式 "/common-service/rest/attachment/downloadFile"
		let url = req.query.url;
		if (url[0] != '/') url = '/' + url;

		var data = {
			"jsonArg": req.query,
			"generalArgument": req.generalArgument
		};
		request({
			headers: {
				'Content-Type': 'application/json;charset=UTF-8',
				'tgt': req.cookies.tgt
			},
			url: `http://sdpd-gateway:11010${url}`,
			method: "POST",
			json: true,
			body: data
		}, function (error, response, body) {
			if (error) {
				res.endj({ code: -1, message: error, data: null });
			} else {
				if (body.code == 0) {
					res.type("text");
					res.write(body.data.stream);
					res.end();
				} else {
					res.endj(body);
				}
			}
		});
	} else {
		midServer(req)
			.downloadFile({ fileId: req.query.fileId })
			.then(function (rsp) {
				res.type("text");
				res.write(rsp.data.stream);
				res.end();
			})
			.catch(res.endj);
	}
});


router.get('/download.file', function (req, res) {
	var data = {
		"jsonArg": req.query,
		"generalArgument": { "ip": "", "loginName": req.query.loginName, "userId": req.query.userId }
	};
	console.log("参数", data);
	request({
		headers: {
			'Content-Type': 'application/json;charset=UTF-8',
			'tgt': req.query.tgt
		},
		url: 'http://sdpd-gateway:11010/common-service/rest/attachment/downloadFile',
		method: "POST",
		json: true,
		body: data
	}, function (error, response, body) {
		if (body.data) {
			res.type("text");
			res.write(Buffer.from(body.data.stream, "base64"));
		}
		res.end();
	});
});

module.exports = router;
