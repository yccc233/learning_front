var router = require("express").Router();
var path = require("path");
// 取消服务
// router.use("/documentserver/", require("./route/documentserver"));

router.get("/onlyoffice", function (req, res) {
	res.set("Content-Type", "text/html");
	res.sendFile(path.join(process.cwd(), `/_build/docviewer/onlyoffice.html`));
});

router.get("/customoffice", function (req, res) {
	res.set("Content-Type", "text/html");
	res.sendFile(path.join(process.cwd(), `/_build/docviewer/customoffice.html`));
});

// 这里可以配置默认使用的工具并保持url不变
router.get("/document", function (req, res) {
	res.set("Content-Type", "text/html");
	res.sendFile(path.join(process.cwd(), `/_build/docviewer/customoffice.html`));
});

module.exports = router;