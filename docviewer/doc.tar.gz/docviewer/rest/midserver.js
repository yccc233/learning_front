var _ = require('underscore');
var path = require('path');
var rest = require(path.join(process.cwd(), 'utils/rest'));
var appConfig = require('../../../config/config.js');
var url = 'http://' + appConfig['sdpd-gateway'] + ':11010/common-service/rest/attachment/';

module.exports = function (req) {
	return {
		"downloadFile": function (args, callback) {
			if (_.isFunction(args)) {
				callback = args;
				args = {};
			}
			return rest(url, "downloadFile", "POST", args, callback, req);
		}
	};
};