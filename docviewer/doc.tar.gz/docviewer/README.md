
# 说明

**修改下载文件方法，不再从docviewer提供的入口下载，兼容多项目，自己配置下载预览地址，所以更新后的参数要求看下面。**


## 用法

使用url跳转
url格式：`http://IP/docviewer/document?opt=eyJmaWxlSWQiOiI2OTMwYjQ5MS1kMjk1LTQyNmItYmU4ZS04NW...`

解析参数：

```js
{
    preview: "/frontcontrol/attachment/previewFile"
    download: "/frontcontrol/attachment/downloadFile"
    fileId: "6930b491-d295-426b-be8e-85f3c688fd8c"
    fileName: "06-系统用户手册"
    fileType: "docx",
    identity: "da4ea2a5506f2693eae190d9360a1f31793c98a1adade51d93533a6f520ace1c",
    redirect: "http://192.5.51.100/frontcontrol/page/frontdetail?opt=eyJmcm9udElkIjoyfQ%3D%3D"
}
```

> fileId：`必须`
>
> fileName：`必须`
>
> fileType：`必须`
>
> preview：`必须`，返回`rsp.data.stream`
>
> download：返回`new Buffer(rsp.data.stream, "base64")`，不传时不显示下载选项
>
> identity：`配置性必须`，用于用户权限控制，防止粘贴url，访问越权文件，由userid经过sha256加密后构成，长度64，参数必要性根据`config.js`的`customofficeconfig.needIdentity`决定
>
> redirect：当identity不匹配的时候，3s后重定向至链接，可不传



对应应用下中间层写法：

```js
router.get("/previewFile", function (req, res) {
  attachmentApi(req)
    .downloadFile({ fileId: req.query.fileId })
    .then(function (rsp) {
        res.type("text");
        res.write(rsp.data.stream);
        res.end();
    })
    .catch(res.endj);
});
```


## 举例

在阵地管控`frontcontrol`中使用文档预览，需要在route添加路由获取文件流，在`restConfig.js`中配置如下
```js
attachment: {
    role: "sdpd-gateway",
    port: 11010,
    url: "/common-service/rest/",
    name: "attachment"
  },
```
然后在route中添加预览和下载接口
```js
// 下载方式
router.get("/downloadFile", function (req, res) {
  attachmentApi(req)
    .downloadFile({ fileId: req.query.fileId })
    .then(function (rsp) {
      res.type("text");
      res.write(new Buffer(rsp.data.stream, "base64"));
      res.end();
      if (rsp.code == 0) {
        // 审计
        auditFunc.recordLogAndProgress(
          "downloadFile",`下载附件：附件名(${req.query.fileName})，附件Id(${req.query.fileId})`,req);
	  }
	})
    .catch(res.endj);
});
// 预览方式
router.get("/previewFile", function (req, res) {
  attachmentApi(req)
    .downloadFile({ fileId: req.query.fileId })
    .then(function (rsp) {
      res.type("text");
      res.write(rsp.data.stream);
      res.end();
    })
    .catch(res.endj);
});
```
预览的时候获取到fileId、fileName、fileType即可：
```jsx
import { appPrefix, genSearchParam, getCookiekey } from "../../utils";
import sha256 from "crypto-js/sha256";
...
<a onClick={() => window.open(
		`/docviewer/document?${genSearchParam({
			fileId: record.fileId,
			fileName: record.fileName,
			fileType: record.fileType,
			preview: `/${appPrefix}/attachment/previewFile`,
			download: `/${appPrefix}/attachment/downloadFile`,
      identity: sha256(getCookiekey("userid")).toString(),
      redirect: window.location.href
		})}`
	)}
>
	{text}
</a>
```




## ONLYOFFICE 

适配onlyoffice时，也需要传递preview，但是需要注意的是url不是通用的请求，需要使用后缀式的url，因为最终是onlyoffice docker调用，所以需要用静态文件式方法跨过cookie的tgt验证
```js
{
    preview: "/frontcontrol/attachment/preview"                // 在html中将url拼接成/frontcontrol/attachment/preview.file
    fileId: "6930b491-d295-426b-be8e-85f3c688fd8c"
    fileName: "06-系统用户手册"
    fileType: "docx"
}
```

html获取onlyoffice的api.js地址在`./config.js`中配置，路径：`onlyofficeConfig.appjsUrl`。

下载时preview的地址通过`./config.js`中`onlyofficeConfig.ipName`配置，这样做是与自定义预览统一，ip单独配置。

```js
var request = require('request');

router.get('/preview.file', function (req, res) {
	var data = {
		"jsonArg": req.query,
		"generalArgument": { "ip": "", "loginName": req.query.loginName, "userId": req.query.userId }
	};
	request({
		headers: {
			'Content-Type': 'application/json;charset=UTF-8',
			'tgt': req.query.tgt
		},
		url: 'http://sdpd-gateway:11010/common-service/rest/attachment/downloadFile',           // 这里的url根据项目内文件下载地址手动配置
		method: "POST",
		json: true,
		body: data
	}, function (error, response, body) {
		if (body.data) {
			res.type("text");
			res.write(Buffer.from(body.data.stream, "base64"));
		}
		res.end();
	});
});
```