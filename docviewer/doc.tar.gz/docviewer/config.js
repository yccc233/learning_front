var configValue;

configValue = {
    customofficeconfig: {
        needIdentity: true
    },
    onlyofficeConfig: {
        appjsUrl: "http://192.5.51.38/web-apps/apps/api/documents/api.js",
        ipName: "app-web"       // 下载文件流的地址，ip名称
    }
};

module.exports = configValue;