import { DragOutlined, LoadingOutlined } from "@ant-design/icons";
import _ from "underscore";
import Notify from "nova-notify";
import Draggable from "react-draggable";
import { Select } from "antd";
const { Option } = Select;


var _local = function () {
	this.events = {};
	/**
	 * 订阅消息
	 * @param {String} eventName	消息名
	 * @param {Function} fn	回调函数
	 */
	this.on = function (eventName, fn) {
		this.events[eventName] = this.events[eventName] || [];
		this.events[eventName].push(fn);
	};

	/**
	 * 退订消息
	 * @param {String} eventName	消息名
	 * @param {Function} fn	订阅的回调函数
	 */
	this.off = function (eventName, fn) {
		if (this.events[eventName]) {
			for (let i = 0; i < this.events[eventName].length; i++) {
				if (this.events[eventName][i] === fn) {
					this.events[eventName].splice(i, 1);
					break;
				}
			}
		}
	};

	/**
	 * 发布消息, 指定消息名, 订阅该消息的所有对象都会收到消息
	 * @param {String} eventName	 消息名
	 * @param {Object} data	事件发布的消息
	 */
	this.emit = function (eventName, data) {
		if (this.events[eventName]) {
			this.events[eventName].forEach(function (fn) {
				fn(data);
			});
		}
	};

	/**
	 * 鉴定消息，防止重复绑定
	 */
	this.isOn = function (eventName) {
		return !!this.events[eventName] && this.events[eventName].length > 0;
	};
};

/**
 * 发布<-->订阅
 * 用于不同组件间通信，同步操作
 */
export let local = new _local();

/**
 * 提交post请求
 * @param {String} url	服务路径
 * @param {Object} postData	请求参数
 * @return {Promise}
 */
export const makePost = function (url, postData) {
	var deferred = Q.defer();
	$.ajax({
		url: url,
		type: "POST",
		async: true,
		data: JSON.stringify(postData),
		contentType: "application/json;charset=UTF-8",
		dataType: "json",
		success: function (res) {
			try {
				if (res.code === 0) deferred.resolve(res.data);
				else deferred.reject(res.message);
			} catch (e) {
				deferred.reject(e);
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			deferred.reject(new Error(errorThrown));
		}
	});
	return deferred.promise;
};


/**
 * 提交get请求
 * @param {String} url	服务路径
 * @param {Object} submitData	请求参数
 * @return {Promise}
 */
export const makeGet = function (url, submitData) {
	var deferred = Q.defer();
	$.ajax({
		url: url,
		type: "GET",
		cache: true,
		async: true,
		data: submitData,
		dataType: "json",
		success: function (res) {
			try {
				if (res.code === 0) {
					deferred.resolve(res.data);
				} else deferred.reject(res.message);
			} catch (e) {
				deferred.reject(e);
			}
		},
		error: function (XMLHttpRequest, textStatus, errorThrown) {
			deferred.reject(new Error(errorThrown));
		}
	});
	return deferred.promise;
};

/**
 * 提示信息统一封装 error类
 * @param {String} message 信息
 * @param {String} title 标题
 */
export const NError = (message, title = "文件异常") => {
	Notify.show({
		title: title,
		text: message,
		type: "error"
	});
};

/**获取 cookie 中的信息 */
export const getCookiekey = (key) => {
	var cookies = document.cookie.split("; ");
	var map = {};
	cookies.forEach(function (cookie) {
		var kv = cookie.split("=");
		map[kv[0]] = kv[1];
	});
	return map[key];
};

/**
 * 生成页面的URL，使用Base64加密
 * @param {Object} opt opt的参数
 * @param {Object} other 其他页面参数
 * @return {String}
 */
export const genSearchParam = (opt, other) => {
	//将对象加密处理
	let sp = new URLSearchParams();
	sp.append("opt", BASE64.encoder(JSON.stringify(opt)));
	_.each(other, (v, k) => {
		sp.append(k, v);
	});
	return sp.toString();
};
window.genSearchParam = genSearchParam;


/**
 * 获取参数中，key为opt的参数值
 * @param {String} search 传入参数: location.search
 * @return {Object}
 */
export const getSearchOpt = search => {
	try {
		if (search[0] === "?") search = search.substring(1, search.length);
	} catch (e) { }
	const searchParam = new URLSearchParams(search);
	//BASE64 框架中jbase64.js中函数自调用后添加window.BASE64属性  框架中通过require引入文件执行JS代码 达到函数自调用
	return JSON.parse(BASE64.decoder(searchParam.get("opt")));
};
window.getSearchOpt = getSearchOpt;

/**
 * antd 样式前缀
 */
export const prefixCls = "docviewant";

/**
 * 应用前缀配置
 */
export const appPrefix = window.__JSC__ && window.__JSC__.business ? window.__JSC__.business.docviewer.appPrefix : "docviewer";

/**
 * 应用配置项
 */
var _appconfig = require("../../../config");
var appconfig =
	window.__JSC__ && window.__JSC__.business
		? window.__JSC__.business.docviewer || {}
		: window.__CONF__ && window.__CONF__.business && window.__CONF__.business.docviewer
			? window.__CONF__.business.docviewer
			: _appconfig;
if (Object.keys(appconfig).length == 0) appconfig = _appconfig;

export const appConfig = appconfig;
export const localConfig = _appconfig;

/**
 *
 * @param {*} queryParams
 */
export const getDecodeParams = queryParams => {
	try {
		if (queryParams[0] === "?") queryParams = queryParams.substring(1, queryParams.length);
	} catch (e) {
		return {};
	}
	const searchParam = new URLSearchParams(queryParams);
	//BASE64 框架中jbase64.js中函数自调用后添加window.BASE64属性  框架中通过require引入文件执行JS代码 达到函数自调用
	let opt = searchParam.get("opt");
	if (opt) {
		opt = opt.replace(/\s/g, "+");
		let decoder = BASE64.decoder(opt);
		let result;
		// 中文乱码捕获parse异常
		try {
			result = JSON.parse(decoder);
		} catch (e) {
			NError("可能存在中文乱码或无参！", "url参数解析失败");
			console.error("待解析参数：", decoder);
			result = {};
		}
		return result;
	}
	return {};
};

/**
 * 对已知类型处理，针对onlyoffice的
 * @param {*} type
 * @returns
 */
export const mapDocumentFileType = type => {
	let documentType = "word",
		fileType = null;
	if (type) {
		type = type.toLowerCase();
		switch (type) {
			case "doc":
			case "docm":
			case "docx":
			case "pdf":
			case "txt":
			case "xml":
			case "htm":
			case "html":
			case "mht":
			case "rtf":
				fileType = type;
				break;
			case "json":
				fileType = "txt";
				break;
			case "csv":
			case "xlsx":
			case "xls":
			case "xlsb":
			case "xlsm":
			case "xlt":
			case "xltm":
			case "xltx":
				documentType = "cell";
				fileType = type;
				break;
		}
	}
	return { documentType, fileType };
};

/**
 * 对类型处理，此方法针对自定义customoffice的，如果不能处理，返回null
 * @param {*} type
 * @returns
 */
export const mapDocumentFileTypeForCustom = type => {
	type = type.toLowerCase();
	switch (type) {
		// case "doc":
		case "docx":
			return "word";
		case "xls":
		case "xlsx":
		case "csv":
			return "excel";
		case "txt":
		case "xml":
		case "htm":
		case "html":
		case "json":
			return "text";
		case "pdf":
			return "pdf";
		case "jpg":
		case "jpeg":
		case "png":
		case "gif":
		case "jpg":
			return "picture";
		default:
			return null;
	}
};

var typeDic = {
	docx: "application/msword",
	doc: "application/msword",
	xls: "application/vnd.ms-excel",
	xlsx: "application/vnd.ms-excel",
	csv: "application/vnd.ms-excel",
	pdf: "application/pdf"
};

/**
 * @param {*} base64Str base64编码
 * @param {*} type 类型
 */
export const Base64ToBlob = (base64Str, type) => {
	const bstr = atob(base64Str);
	let n = bstr.length;
	const u8arr = new Uint8Array(n);
	while (n--) {
		u8arr[n] = bstr.charCodeAt(n);
	}
	return new Blob([u8arr], { type: typeDic[type] });
};

export const Base64ToGB2312 = base64Str => {
	var strout = "";
	var z = "{0}";
	for (var i = 0; i < base64Str.length; i++) {
		var c = base64Str.charAt(i);
		if (c == "+") {
			strout += "";
		} else if (c != "%") {
			strout += c;
		} else {
			i++;
			var nextC = base64Str.charAt(i);
			if (!isNaN(parseInt(nextC))) {
				i++;
				strout += decodeURIComponent(c + nextC + base64Str.charAt(i));
			} else {
				var x = new String();
				try {
					var code = base64Str.substr(i, 2) + base64Str.substr(i + 3, 2);
					i += 4;
					var index = -1;
					while ((index = z.indexOf(code, index + 1)) != -1) {
						if (index % 4 == 0) {
							strout == String.fromCharCode(index / 4 + 19968);
							bresk;
						}
					}
				} catch (e) { }
			}
		}
	}
	return strout;
};

// 首字母大写
export function customCaptain(str) {
	return `${str.charAt(0).toUpperCase()}${str.slice(1)}`;
}

export const customIndexedColors = [
	"000000",
	"FFFFFF",
	"FF0000",
	"00FF00",
	"0000FF",
	"FFFF00",
	"FF00FF",
	"00FFFF",
	"000000",
	"FFFFFF",
	"FF0000",
	"00FF00",
	"0000FF",
	"FFFF00",
	"FF00FF",
	"00FFFF",
	"800000",
	"008000",
	"000080",
	"808000",
	"800080",
	"008080",
	"C0C0C0",
	"808080",
	"9999FF",
	"993366",
	"FFFFCC",
	"CCFFFF",
	"660066",
	"FF8080",
	"0066CC",
	"CCCCFF",
	"000080",
	"FF00FF",
	"FFFF00",
	"00FFFF",
	"800080",
	"800000",
	"008080",
	"0000FF",
	"00CCFF",
	"CCFFFF",
	"CCFFCC",
	"FFFF99",
	"99CCFF",
	"FF99CC",
	"CC99FF",
	"FFCC99",
	"3366FF",
	"33CCCC",
	"99CC00",
	"FFCC00",
	"FF9900",
	"FF6600",
	"666699",
	"969696",
	"003366",
	"339966",
	"003300",
	"333300",
	"993300",
	"993366",
	"333399",
	"333333",
	"b7e0ff",
	"00CCFF"
];

export const StringToBytes = (encoding) => {
	var bytes = [];
	var buff = Buffer.from(encoding);
	for (var i = 0; i < buff.length; i++) {
		var byteint = buff[i];
		bytes.push(byteint);
	}
	return bytes;
}

/**
 * 根据解码类型将stream转换为对应的数据
 * @param {*} stream 
 * @param {*} type 
 * @returns 
 */
export const transformStreamToDecode = (stream, type) => {
	var bytes = Buffer.from(stream, "base64");
	switch (type) {
		case "gbk":
			return new TextDecoder(type).decode(bytes);
		default:            // utf8
			return bytes.toString(type);
	}
}

/**
 * 配合上面的组件
 */
export const SelectDecode = ({ defaultDecode, onChange }) => (
	<Draggable
		handle=".arrow-hover-hide"
	>
		<div className="select-decode">
			<DragOutlined className="arrow-hover-hide" style={{ fontSize: 24, color: "#1890ff" }} />
			<Select style={{ width: 150 }} className="select-and" defaultValue={defaultDecode} onChange={onChange}>
				<Option value="utf8">utf-8</Option>
				<Option value="gbk">gbk</Option>
			</Select>
		</div>
	</Draggable>
)

/**
 * 加载组件
 */
export const LoadingCustom = () => <div className="custom-loading"><LoadingOutlined className="mr10" /> 加载中.....</div>;