import React, { Component } from "react";
import ExcelJS from "exceljs";
import Handsontable from "handsontable";
import { registerLanguageDictionary, zhCN } from "handsontable/i18n";
import "handsontable/dist/handsontable.full.min.css";
import { registerAllModules } from "handsontable/registry";
import { parse } from "fast-csv";
import { Base64ToBlob, customCaptain, transformStreamToDecode, SelectDecode, LoadingCustom } from "../../util";
import moment from "moment";

// 注册中文
registerLanguageDictionary(zhCN);
registerAllModules();

class Excel extends Component {
	constructor(props) {
		super(props);
		this.state = {
			loading: true,
			sheet: null,
			sheetConfig: null,

			decode: 'utf8'
		};

		this.hot = null;
		this.workbook = null;
		this.ws = null;
		this.themeColors = null;
		this.merge = null;
		this.mergeButNotLastPoint = [];

		this.getData = this.getData.bind(this);
		this.getCell = this.getCell.bind(this);
		this.getMerge = this.getMerge.bind(this);
		this.getColumns = this.getColumns.bind(this);
		this.renderExcel = this.renderExcel.bind(this);
		this.renderExcel = this.renderExcel.bind(this);
		this.changeDecode = this.changeDecode.bind(this);
		this.judgeRenderStyle = this.judgeRenderStyle.bind(this);
	}

	fixMatrix(data, colLen) {
		for (let row of data) {
			for (let j = 0; j < colLen; j++) {
				if (!row[j]) {
					row[j] = '';
				}
			}
		}
		return data;
	}

	alignToClass({ horizontal, vertical }) {
		return [horizontal, vertical]
			.filter(i => i)
			.map(key => `ht${key.charAt(0).toUpperCase()}${key.slice(1)}`)
			.join(" ");
	}

	getValue(value, style = {}) {
		switch (typeof value) {
			case "string": case "number":
				return value;
			case "object":
				// 解析的时间不对, style.numFmt与moment不匹配
				if (value instanceof Date) {
					return moment(value).format("yyyy-MM-DD hh:mm:ss");
				}
				return value.richText ? value.richText.text : value;
			default:
				return "";
		}
	}

	getData() {
		return this.fixMatrix(
			(this.ws.getRows(1, this.ws.rowCount) || []).map(row =>
				row._cells.map(item => {
					const { value, style } = item.model;
					// if (value) {
					// 	return value.richText ? value.richText.text : value;
					// }
					return this.getValue(value, style);
				})
			),
			(this.ws.columns || []).length
		);
	}

	getCell() {
		if (!!Array.flatMap) {
			return (this.ws.getRows(1, this.ws.rowCount) || []).flatMap((row, ri) =>
				row._cells
					.map((cell, ci) => {
						return {
							row: ri,
							col: ci,
							...(cell.alignment ? { className: this.alignToClass(cell.alignment) } : {}),
							style: cell.style ? cell.style : {}
						};
					})
			);
		} else {
			let cellArr = [];
			(this.ws.getRows(1, this.ws.rowCount) || []).forEach((row, ri) => {
				cellArr.concat(
					row._cells
						.map((cell, ci) => {
							return {
								row: ri,
								col: ci,
								...(cell.alignment ? { className: this.alignToClass(cell.alignment) } : {}),
								style: cell.style ? cell.style : {}
							};
						})
				);
			});
			return cellArr;
		}
	}

	getMerge() {
		this.merge = Object.values(this.ws._merges).map(({ left, top, right, bottom }) => ({
			row: top - 1,
			col: left - 1,
			rowspan: bottom - top + 1,
			colspan: right - left + 1
		}));
		this.mergeButNotLastPoint = this.getMergeButNotLastPoints(this.merge);
		return this.merge;
	}

	getColumns() {
		return (this.ws.columns || []).slice(0, this.ws.columnCount + 5).map(item => ({
			width: isNaN(item.width) ? 100 : item.width * 10,
			className: this.alignToClass(item.alignment || {}),
			renderer: "styleRender"
		}));
	}

	getRowHeights() {
		// 页面设置了最小高度是24px
		return this.ws._rows.map(item => item.height ? item.height : 24);
	}

	componentDidMount() {
		const that = this;
		if (this.props.preview) {
			this.registerRenderer();
			$.get(`${this.props.preview}?fileId=${that.props.fileId}`).then(data => {
				this.renderExcel(data);
				this.setState({ stream: data });
			});
		} else {
			console.error("请配置预览方式");
		}
	}

	renderExcel(stream) {
		const that = this;
		if (that.props.fileType == "csv") {
			// csv处理
			stream = transformStreamToDecode(stream, that.state.decode);
			var csv_rows = [];
			const csv_stream = parse({ headers: false })
				.on("error", e => console.error(e))
				.on("data", r => csv_rows.push(Object.values(r)))
				.on("end", _ => that.renderHandson(csv_rows));
			csv_stream.write(stream);
			csv_stream.end();
		} else {
			// xlsx处理
			const blobdata = Base64ToBlob(stream, that.props.fileType);
			new ExcelJS.Workbook().xlsx
				.load(blobdata)
				.then(workbook => {
					that.workbook = workbook;
					that.parseTheme();
					const sheets = workbook._worksheets.filter(ws => ws);
					const firstSt = sheets[0];
					that.ws = workbook.getWorksheet(firstSt.id);
					// 计算data
					const cdata = that.getData();
					// 计算cell
					const cell = that.getCell();
					// 计算merge
					const merge = that.getMerge();
					// 计算
					const columns = that.getColumns();
					// 行高
					const rowheight = that.getRowHeights();
					that.renderHandson(cdata, cell, merge, columns, rowheight);
					that.setState({
						sheet: firstSt.id,
						sheetConfig: sheets
					});
				})
				.catch(e => console.error(e));
		}
	}

	renderHandson(data, cell, merge, columns, rowHeights) {
		const container = document.getElementById("custom-excel");
		this.hot = new Handsontable(container, {
			language: "zh-CN",
			readOnly: true,
			data: data,
			cell: cell,
			mergeCells: merge,
			columns: columns,
			rowHeights: rowHeights,
			colHeaders: true,
			rowHeaders: true,
			height: this.props.fileType == "csv" ? "calc(100vh)" : "calc(100vh - 30px)",
			// 关闭外部点击取消选中事件行为
			outsideClickDeselects: true,
			licenseKey: "non-commercial-and-evaluation"
		});
		this.setState({ loading: false });
	}

	parseTheme() {
		const theme = this.workbook._themes.theme1;
		const parser = new DOMParser();
		if (theme) {
			const doc = parser.parseFromString(theme, "text/xml");
			const [{ children = [] } = {}] = doc.getElementsByTagName("a:clrScheme");

			if (!!Array().flatMap) {
				this.themeColors = ['777777'].concat([...children]
					.flatMap(node => [...node.getElementsByTagName("a:srgbClr")])
					.map(node => node.getAttribute("val"))
					.filter(i => i)
				);
			} else {
				let tmpArr = [];
				[...children].forEach(node => {
					tmpArr.concat(node.getElementsByTagName("a:srgbClr"));
				});
				this.themeColors = ['777777'].concat(tmpArr.map(node => node.getAttribute("val")).filter(i => i));
			}
		}
	}

	getMergeButNotLastPoints(merge) {
		let mergeandnotlastpoints = [];
		merge.forEach(m => {
			for (var i = 0; i < m.rowspan; i++) {
				for (var j = 0; j < m.colspan; j++) {
					if (!(
						i == 0 && j == 0
					))
						mergeandnotlastpoints.push([m.row + i, m.col + j]);
				}
			}
		})
		return mergeandnotlastpoints;
	}

	judgeRenderStyle(row, col) {
		// 判断现在item是不是merge里面的，是的话且不是最后一个不渲染，返回bool
		return this.mergeButNotLastPoint ? this.mergeButNotLastPoint.findIndex(p => p[0] == row && p[1] == col) == -1 : true;
	}

	registerRenderer() {
		// 注册自定义渲染
		const _borders = ["left", "right", "top", "bottom"];
		// const _ABCD = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
		Handsontable.renderers.registerRenderer("styleRender", (hotInstance, TD, row, col, prop, value, cell) => {
			Handsontable.renderers.getRenderer("text")(hotInstance, TD, row, col, prop, value, cell);
			if (this.ws && cell.style) {
				const {
					style: { fill, font }
				} = cell;
				// cell中的border不准确
				let border = {};
				if (this.ws._rows[row]._cells[col] && this.ws._rows[row]._cells[col].style) {
					border = this.ws._rows[row]._cells[col].style && this.ws._rows[row]._cells[col].style.border;
					if (!border) border = {};
				}

				// console.log(row + 1 + '', _ABCD[col] + '：', border, height);
				const style = TD.style;
				if (font) {
					if (font.bold) style.fontWeight = "bold";
					if (font.italic) style.fontStyle = "italic";
					if (font.underline) style.textDecoration = "underline";
					if (font.size) style.fontSize = `${font.size}px`;
					if (font.name) style.fontFamily = font.name;
					if (font.color) {
						if (font.color.argb) style.color = '#' + font.color.argb.substring(2, 8) + font.color.argb.substring(0, 2);
						else if (font.color.theme) style.color = '#' + this.themeColors[font.color.theme - 1];
					}
				}
				if (fill && fill.bgColor && fill.bgColor.argb) {
					style.backgroundColor = '#' + fill.bgColor.argb.substring(2, 8) + fill.bgColor.argb.substring(0, 2);

				} else if (fill && fill.fgColor && fill.fgColor.argb) {
					style.backgroundColor = '#' + fill.fgColor.argb.substring(2, 8) + fill.fgColor.argb.substring(0, 2);
				}
				if (Object.keys(border).length > 0 && this.judgeRenderStyle(row, col)) {
					// border逻辑巨复杂，不用管它，border的样式如果
					const merge = this.merge.find(m => m.row == row && m.col == col)
					if (merge) {
						border['right'] = this.ws._rows[row + merge.rowspan - 1]._cells[col + merge.colspan - 1].style.border['right'];
						border['bottom'] = this.ws._rows[row + merge.rowspan - 1]._cells[col + merge.colspan - 1].style.border['bottom'];
					}
					_borders
						.map(key => ({ key, value: border[key] }))
						.filter(v => v.value)
						.forEach(v => {
							const {
								key,
								value: { style: borderStyle }
							} = v;
							const prefix = `border${customCaptain(key)}`;
							if (borderStyle == "thin") {
								// style[`${prefix}Width`] = "1px";
							} else if (borderStyle == "medium") {
								style[`${prefix}Width`] = "2px";
							} else {
								style[`${prefix}Width`] = "3px";
							}
							style[`${prefix}Style`] = "solid";
							style[`${prefix}Color`] = "#000";
							// style[`${prefix}Color`] = `#${(value.color && value.color.theme) ? this.themeColors[value.color.theme-1] : "000"}`;
						});
				}
			}
			// 启用了内联css，直接赋值
			if (cell.css) {
				const style = TD.style;
				const { css } = cell;
				Object.keys(css).forEach(key => {
					const k = camelCase(key);
					style[k] = css[key];
				});
			}
		});
	}

	changeSheet(id) {
		this.ws = this.workbook.getWorksheet(id);
		this.hot.updateSettings({
			data: this.getData(),
			cell: this.getCell(),
			mergeCells: this.getMerge(),
			columns: this.getColumns(),
			rowHeights: this.getRowHeights(),
		});
		this.setState({ sheet: id });
	}

	changeDecode(value) {
		this.setState({ decode: value }, () => this.renderExcel(this.state.stream));
	}

	render() {
		const { sheetConfig, sheet, loading, decode } = this.state;
		return (
			<React.Fragment>
				{loading && <LoadingCustom />}
				<div id="custom-excel"></div>
				{this.props.fileType == "csv" && <SelectDecode defaultDecode={decode} onChange={this.changeDecode} />}
				{sheet && sheetConfig && (
					<div className="excel-sheets">
						{sheetConfig.map(st => (
							<button key={st.name + st.id} className={sheet == st.id ? "checked" : null} onClick={() => this.changeSheet(st.id)}>
								{st.name}
							</button>
						))}
					</div>
				)}
			</React.Fragment>
		);
	}
}

export default Excel;
