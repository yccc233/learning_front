import React, { Component } from 'react';
import { SelectDecode } from '../../util';

/**
 * @param {*} fileId
 * @param {*} fileType
 */
class Text extends Component {
    constructor(props) {
        super(props);
        this.state = {
            stream: null,
            texts: null,
            decode: 'utf8'
        };
    }

    transform(stream, type) {
        var bytes = Buffer.from(stream, "base64");
        switch (type) {
            case "gbk":
                return new TextDecoder(type).decode(bytes);
            default:            // utf8
                return bytes.toString(type);
        }
    }

    componentDidMount() {
        if (this.props.preview) {
            $.get(`${this.props.preview}?fileId=${this.props.fileId}`)
                .then(rsp => {
                    this.setState({ stream: rsp, texts: this.transform(rsp, this.state.decode) });
                });
        } else {
            this.setState({ texts: "请配置预览方式！" })
        }
    }

    render() {
        return <div id="custom-text" className="text" >
            <SelectDecode defaultDecode={this.state.decode} onChange={(v) => this.setState({ decode: v, texts: this.transform(this.state.stream, v) })} />
            <div className="pre-container">
                <div className={this.state.texts ? "content" : null}>
                    {this.state.texts}
                </div>
            </div>
        </div>;
    }
}

export default Text;