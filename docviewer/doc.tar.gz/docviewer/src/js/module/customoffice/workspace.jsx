import React, { Component, useEffect, useState, useRef } from "react";
import { StopOutlined } from "@ant-design/icons";
import { Result, Button } from "antd";
import { withRouter } from "react-router-dom";
import { getSearchOpt, local, mapDocumentFileTypeForCustom, NError, getCookiekey, localConfig } from "../util";
import Word from "./word";
import Excel from "./excel";
import Text from "./text";
import Pdf from "./pdf";
import Picture from "./picture";
import ErrorHappened from "../errorboundary";
import sha256 from "crypto-js/sha256";
import "../../../less/customoffice.less";

/**
 * @param {*} fileId		文件id，必需
 * @param {*} fileName		文件名称
 * @param {*} fileType		文件类型
 * @param {*} download		文件下载前缀，如/frontcontrol/attachment/downloadFile，且url为get方法
 */
class Workspace extends Component {
	constructor(props) {
		super(props);
		this.args = getSearchOpt(props.location.search);
		this.componentType = mapDocumentFileTypeForCustom(this.args.fileType);
		this.identity = sha256(getCookiekey("userid")).toString();
		this.identityPass = false;

		// 鉴权
		if (localConfig.customofficeconfig.needIdentity) {
			if (this.args.identity === this.identity) {
				this.identityPass = true;
			}
		} else {
			this.identityPass = true;
		}

		local.on('getFileError', (msg) => {
			NError(msg);
		});
	}

	componentDidMount() {
		let name = '文档预览';
		if (this.args.fileName) {
			name = this.args.fileName;
			if (this.args.fileType) {
				name += "." + this.args.fileType;
			}
		}
		document.title = name;
	}

	componentWillUnmount() {
		local.off('getFileError');
	}

	render() {
		let docCom = null;
		if (!this.identityPass) docCom = <NoPermission {...this.args} />;
		else if (!this.args.preview) docCom = <EmptyWay {...this.args} />;
		else if (this.componentType == "word") docCom = <Word {...this.args} />;
		else if (this.componentType == "excel") docCom = <Excel {...this.args} />;
		else if (this.componentType == "text") docCom = <Text {...this.args} />;
		else if (this.componentType == "pdf") docCom = <Pdf {...this.args} />;
		else if (this.componentType == "picture") docCom = <Picture {...this.args} />;
		else docCom = <EmptyWay {...this.args} />;

		return <ErrorHappened>
			{docCom}
		</ErrorHappened>;
	}
}

// 无权限预览的组件
const NoPermission = (props) => {
	const [restTime, setRestTime] = useState(3);
	const timeRef = useRef();

	useEffect(() => {
		if (props.redirect) {
			timeRef.current = setInterval(() => {
				setRestTime(pre => pre - 1);
			}, 1000);
		}

		return () => clearInterval(timeRef.current);
	}, []);

	useEffect(() => {
		if (restTime === 0 && props.redirect) {
			setTimeout(() => {
				clearInterval(timeRef.current);
				window.location.href = props.redirect;
			}, 100);
		}
	}, [restTime]);

	return <Result
		icon={<StopOutlined style={{ color: "#ff4d4f" }} />}
		className="custom-empty"
		title="您无访问此文件权限"
		subTitle={props.redirect ? <span>{restTime} s后重定向至 {props.redirect}</span> : undefined}
		extra={[
			props.redirect ? <Button key="NoPermission1" onClick={() => window.location.href = props.redirect}>
				返回
			</Button> : null,
			<Button key="NoPermission2" onClick={() => window.close()}>
				关闭
			</Button>
		]}
	/>;
};

// 无预览方法的组件
const EmptyWay = (props) => {
	return <Result
		className="custom-empty"
		status="error"
		title={props.preview ? "该文件无法在线预览" : "该文件没有预览地址"}
		subTitle={<span>请下载文件至本地预览<br />{props.fileName}.{props.fileType}</span>}
		extra={[
			props.download ?
				<a
					key="EmptyWay1"
					href={`${props.download}?fileId=${props.fileId}&fileName=${`${props.fileName}.${props.fileType}`}&referer=${window.location.pathname}&record=true`}
					download={`${props.fileName}.${props.fileType}`}
					target="_blank"
				>
					<Button type="primary">
						下载
					</Button>
				</a> : null,
			<Button key="EmptyWay2" onClick={() => window.close()}>
				关闭
			</Button>
		]}
	/>;
};

export default withRouter(Workspace);
