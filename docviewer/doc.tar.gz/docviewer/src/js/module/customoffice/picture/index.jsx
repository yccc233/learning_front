import React, { useEffect, useState } from 'react';
import Image from './imagepreview';


function Picture(props) {

    const [src, setSrc] = useState(null);

    useEffect(() => {
        if (props.preview) {
            $.get(`${props.preview}?fileId=${props.fileId}`).then(data => {
                setSrc(data);
            });
        }
    }, []);
    if (!src) return null;
    return <Image imgsrc={`data:image/png;base64,${src}`} />;
}

export default Picture;