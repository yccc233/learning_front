initLocales();

import { getDecodeParams, getCookiekey, error, mapDocumentFileType, localConfig } from "../module/util";

// url参数
// fileId * 文件的id
// fileName 文件名称，没有显示为未知文件
// fileType 文件类型，一般要带有，默认docx；如pdf文件在docx模式下加载后会报错
// docType 	文档类型，只在cell，word中取值，不传的话会根据fileType判断类型
var queryObjs = getDecodeParams(window.location.search);
let posturl =
	`http://${localConfig.onlyofficeConfig.ipName}${queryObjs.preview}.file?fileId=${queryObjs.fileId}&fileName=${queryObjs.fileName || ""}&tgt=${getCookiekey("tgt")}&loginName=${getCookiekey(
		"username"
	)}&userId=${getCookiekey("userid")}`;
// 解析文件类型
// documentType是文档类型，fileType是文件类型
let { documentType, fileType } = mapDocumentFileType(queryObjs.fileType);
["word", "cell"].includes(queryObjs.docType) && (documentType = queryObjs.docType);

if (fileType) {
	var config = {
		type: "desktop",
		document: {
			title: queryObjs.fileName || "未知文件",
			key: new Date().getTime() + Math.random() + "",
			url: posturl,
			fileType: fileType,
			permissions: {
				download: false,
				print: false
			}
		},
		documentType: documentType,
		editorConfig: {
			mode: "view", // view 只读 || edit 编辑，目前不支持编辑后文件回调
			lang: "zh",
			user: {
				name: getCookiekey("username"),
				id: getCookiekey("userid")
			},
			customization: {
				chat: false,
				comments: false,
				forcesave: false,
				help: false
			}
		},
		events: {
			onAppReady: function () {
				document.title = queryObjs.fileName || "文档预览";
			}
		}
	};
	if(window.DocsAPI) {
		var docEditor = new DocsAPI.DocEditor("content-wrapper", config);
	} else {
		
	}
} else error("该文件类型目前不支持在线查看！");

hideLoader();
