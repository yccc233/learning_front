initLocales();
import React from "react";
import ReactDOM from "react-dom";
import { ConfigProvider, message } from "antd";
import zhCN from "antd/lib/locale-provider/zh_CN";
import { BrowserRouter as Router } from "react-router-dom";
import { prefixCls, appPrefix } from "../module/util";
import Workspace from "../module/customoffice/workspace";

let topTray = $("#topbar");
const containerHeight = window.innerHeight - topTray.offset().top - 32;

$("#content-wrapper").height(containerHeight);

/**消息的全局配置 */
message.config({
	top: 40,
	prefixCls: `${prefixCls}-message`
});

const getConfirmation = (message, callback) => {
	confirm({
		prefixCls: `${prefixCls}-modal`,
		title: "确认离开该页面吗?",
		content: message,
		okType: "danger",
		okText: "确定",
		cancelText: "取消",
		onOk() {
			callback(true);
		}
	});
};

function App() {
	return <Router basename={`/${appPrefix}/page`} getUserConfirmation={getConfirmation}>
		<Workspace />
	</Router>;
}

const init = function (id) {
	hideLoader();
	/**隐藏框架左侧边栏 */
	$(".dashboard-page").addClass("sb-l-c");
	ReactDOM.render(
		<ConfigProvider locale={zhCN} prefixCls={prefixCls}>
			<App />
		</ConfigProvider>,
		document.getElementById(id)
	);
};

init("content-wrapper");
