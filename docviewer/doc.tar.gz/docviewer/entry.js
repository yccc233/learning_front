module.exports = {
	onlyoffice: "./pages/onlyoffice.jsx",
	customoffice: "./pages/customoffice.jsx"
};